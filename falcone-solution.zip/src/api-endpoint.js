export const PLANETS_API = "https://findfalcone.herokuapp.com/planets";

export const VEHICLES_API = "https://findfalcone.herokuapp.com/vehicles";

export const FIND_TOKEN_API = "https://findfalcone.herokuapp.com/token";

export const FIND_CHECK_API = "https://findfalcone.herokuapp.com/find";

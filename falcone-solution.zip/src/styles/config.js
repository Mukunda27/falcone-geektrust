const config = {
  breakpoint: {
    lg: 1200,
  },
  containerMaxWidth: 1600,
};

export default config;
